Copyright Notice:
-----------------
The files within this zip file are copyrighted by Lazy Foo' Productions (2004-2020)
and may not be redistributed without written permission.

This project is linked against:
----------------------------------------
Windows:
SDL2
SDL2main
SDL2_image
SDL2_ttf

*nix:
SDL2
SDL2_image
SDL2_ttf
